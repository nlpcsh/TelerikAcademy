﻿namespace SimpleT4
{
    public class ToTestT4
    {
        public Student student1 { get; set; }
        public Student student2 { get; set; }
        public Student student3 { get; set; }
        public Student student4 { get; set; }
        public Student student5 { get; set; }
        public Student student6 { get; set; }
        public Student student7 { get; set; }
        public Student student8 { get; set; }
        public Student student9 { get; set; }
    }
}