﻿namespace SimpleT4
{
    class Student
    {
    }
}
