﻿namespace SimpleT4
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
